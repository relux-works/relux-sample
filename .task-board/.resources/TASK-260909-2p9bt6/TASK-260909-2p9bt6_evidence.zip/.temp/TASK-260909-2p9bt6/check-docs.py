from pathlib import Path
import re, sys, urllib.parse, xml.etree.ElementTree as ET
files = [Path('README.md'), Path('README.ru.md'), Path('PROJECT_GUIDE.md'), Path('.spec/refresh-sample.md'), *Path('Docs').rglob('*.md'), Path('diagrams/README.md')]
checked=0; errors=[]
for f in files:
    text=f.read_text()
    if text.count('```') % 2: errors.append(f'{f}: unbalanced fences')
    for link in re.findall(r'\]\(([^)]+)\)',text):
        if '://' in link or link.startswith('mailto:') or not link: continue
        target, _, anchor = urllib.parse.unquote(link).partition('#')
        p=f.parent/target if target else f
        checked+=1
        if not p.exists(): errors.append(f'{f}: missing {link}'); continue
        if anchor and p.suffix=='.md':
            headings=[]
            for h in re.findall(r'^#+\s+(.+)$',p.read_text(),re.M):
                h=re.sub(r'[^\w\- ]','',h.lower()).replace(' ','-'); headings.append(h)
            if anchor not in headings: errors.append(f'{f}: missing anchor {link}')
for f in Path('diagrams/rendered').glob('*.svg'):
    ET.parse(f)
print(f'Checked {checked} local Markdown links across {len(files)} documents; {len(errors)} errors.')
print('Bound: local inline Markdown links, heading anchors and XML parsing; external URLs and visual layout require separate review.')
for err in errors: print(err)
sys.exit(bool(errors))
