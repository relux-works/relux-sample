public typealias Seconds = Double
