from pathlib import Path
from urllib.parse import unquote
import re
import sys
files = ['README.md', '.spec/note-protection.md']
missing = []
count = 0
for name in files:
    path = Path(name)
    for link in re.findall(r'\]\(([^)]+)\)', path.read_text()):
        if '://' in link or link.startswith('#'):
            continue
        target = unquote(link.split('#', 1)[0])
        if not target:
            continue
        count += 1
        if not (path.parent / target).exists():
            missing.append((name, target))
print(f'Checked {count} local link targets in {len(files)} changed documents.')
for name, target in missing:
    print(f'MISSING {name}: {target}')
sys.exit(1 if missing else 0)
