"""Task-scoped behavioral mutation probe. Restores exact source bytes after every run."""
import json
import subprocess
import sys
from pathlib import Path

root = Path.cwd()
out = root / '.temp/TASK-260909-1b1pyo'
provider = 'relux_sample/Modules/Notes/Data/Api/Notes+Data+Api+Fetcher.swift'
mutants = {
 'locked-upsert': (provider, 'guard canAccess(note.id) else', 'guard canAccess(note.id) || note.title == "Visible title" else'),
 'locked-delete': (provider, 'guard canAccess(id) else', 'guard canAccess(id) || notes[id]?.title == "Visible title" else'),
 'remove-lock': (provider, 'guard canAccess(noteId) else', 'guard canAccess(noteId) || note.title == "Visible title" else'),
 'redaction': (provider, 'locked ? "" : note.content', 'locked && note.title != "Visible title" ? "" : note.content'),
 'false-auth': (provider, 'guard authorized, !Task.isCancelled,', 'guard authorized || note.title == "Visible title", !Task.isCancelled,'),
 'cancelled-task': (provider, 'guard authorized, !Task.isCancelled,', 'guard authorized, !Task.isCancelled || note.title == "Visible title",'),
 'late-generation': (provider, 'generations[noteId, default: 0] == generation,', 'generations[noteId, default: 0] <= generation + 1,'),
 'metadata': (provider, 'isProtected: notes[note.id]?.isProtected ?? false)', 'isProtected: note.title == "Edited" ? note.isProtected : (notes[note.id]?.isProtected ?? false))'),
 'cross-note': (provider, '!grants.contains(note.id)', '!(grants.contains(note.id) || (note.title == "Other" && !grants.isEmpty))'),
 'snapshot-replay': ('relux_sample/Modules/Notes/Business/Notes+Business+State+Reducer.swift', 'snapshot.revision > revision', 'snapshot.revision >= revision'),
 'editor': ('relux_sample/Modules/Notes/Business/Model/Notes+Business+Model+Note.swift', 'isLocked ? nil : self', 'isLocked && title != "Visible title" ? nil : self'),
 'auth-false': ('Packages/Auth/Sources/AuthReluxImpl/Business/Middleware/Auth+Business+Flow.swift', 'case .success(false): return .failure(.authenticationRejected)', 'case .success(false): return .success(())'),
 'auth-unavailable': ('Packages/Auth/Sources/AuthReluxImpl/Business/Middleware/Auth+Business+Flow.swift', 'case .failure(let error): return .failure(error)', 'case .failure(let error):\n                if case .unavailable = error { return .success(()) }\n                return .failure(error)'),
 'auth-cancelled': ('Packages/Auth/Sources/AuthReluxImpl/Business/Middleware/Auth+Business+Flow.swift', 'case .failure(let error): return .failure(error)', 'case .failure(let error):\n                if case .cancelled = error { return .success(()) }\n                return .failure(error)'),
}
mutants['auth-cancelled-task'] = (
    'Packages/Auth/Sources/AuthReluxImpl/Business/Middleware/Auth+Business+Flow.swift',
    'let result = await svc.runLocalAuth()\n            guard !Task.isCancelled else',
    'let result = await svc.runLocalAuth()\n            guard !Task.isCancelled || (try? result.get()) == true else'
)
mutants['auth-policy-unavailable'] = (
    'Packages/Auth/Sources/AuthServiceImpl/Auth+Business+Service.swift',
    'guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else',
    'guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) || error?.code == LAError.passcodeNotSet.rawValue else'
)
mutants['auth-credential-fallback'] = (
    'Packages/Auth/Sources/AuthServiceImpl/Auth+Business+Service.swift',
    '.deviceOwnerAuthentication, localizedReason: "Unlock this note."',
    '.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Unlock this note."'
)
for mutant, binding in [('missing-unlock', 'let'), ('missing-protection', 'var')]:
    mutants[mutant] = (
        provider,
        f'guard {binding} note = notes[noteId] else {{ return .failure(.notFound) }}',
        f'guard {binding} note = notes[noteId] else {{ return noteId == UUID(uuidString: "00000000-0000-0000-0000-000000000001")! ? .success(()) : .failure(.notFound) }}'
    )
mutants['late-note-existence'] = (provider, 'notes[noteId]?.isProtected == true else', 'notes[noteId]?.isProtected != false else')
name = sys.argv[1]
file, before, after = mutants[name]
path = root / file
original = path.read_bytes()
source = original.decode()
assert source.count(before) == (2 if name in ("auth-unavailable", "auth-cancelled") else 1), (name, source.count(before))
if name.startswith('auth-'):
    command = ['swift', 'test', '--package-path', 'Packages/Auth', '--force-resolved-versions']
else:
    command = ['xcodebuild', 'test', '-project', 'relux_sample.xcodeproj', '-scheme', 'relux_sample',
               '-destination', 'platform=iOS Simulator,name=iPhone 17', '-derivedDataPath', '.temp/DerivedData',
               '-parallel-testing-enabled', 'NO', '-disableAutomaticPackageResolution',
               '-onlyUsePackageVersionsFromResolvedFile', '-only-testing:relux_sampleTests/NoteProtectionTests',
               'CODE_SIGNING_ALLOWED=NO']
try:
    path.write_text(source.replace(before, after, 1))
    with (out / f'mutant-{name}.log').open('w') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=300)
    record = dict(mutant=name, file=file, before=before, after=after, command=command, exit_code=result.returncode)
    (out / f'mutant-{name}.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record))
finally:
    path.write_bytes(original)
